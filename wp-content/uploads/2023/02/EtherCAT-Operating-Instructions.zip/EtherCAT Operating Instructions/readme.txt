文件“TEC_EtherCat_E101 one-magnet.xml”只支持一个磁铁，方便单磁铁用户及适配国内部分控制器。
文件“TEC_EtherCat_E101.xml”只支持1-8个磁铁。